package org.testsuite.das4.exceptions;

public class ScriptException extends Exception {
    public ScriptException(String msg) { super(msg); }
}
