package org.testsuite.exceptions;

public class TestSuiteException extends Exception {
    public TestSuiteException(String msg) { super(msg); }
}
